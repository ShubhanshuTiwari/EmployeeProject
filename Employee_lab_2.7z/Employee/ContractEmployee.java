package Employee;

public class ContractEmployee {

}
