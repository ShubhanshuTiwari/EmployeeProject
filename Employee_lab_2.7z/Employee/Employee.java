//package Employee;
//public class Employee {
//	private int empId;
//	private String fname;
//	private String lname;
//	private double Salary;
//	private char grade;
//	private String joiningDate;
//	private String contracterName;
//	
//	public Employee(int empId, String fname, String lname, double salary, char grade, String joiningDate) {
//		
//		this.empId = empId;
//		this.fname = fname;
//		this.lname = lname;
//		Salary = salary;
//		this.grade = grade;
//		this.joiningDate = joiningDate;
//	}
//	
//	public Employee(int empId, String fname, String lname, double salary, char grade, String joiningDate,
//			String contracterName) {
//		super();
//		this.empId = empId;
//		this.fname = fname;
//		this.lname = lname;
//		Salary = salary;
//		this.grade = grade;
//		this.joiningDate = joiningDate;
//		this.contracterName = contracterName;
//	}
//
//	public Employee() {
//		
//	}
//	public int getEmpId() {
//		return empId;
//	}
//	public void setEmpId(int empId) {
//		this.empId = empId;
//	}
//	public String getFname() {
//		return fname;
//	}
//	public void setFname(String fname) {
//		this.fname = fname;
//	}
//	public String getLname() {
//		return lname;
//	}
//	public void setLname(String lname) {
//		this.lname = lname;
//	}
//	public double getSalary() {
//		return Salary;
//	}
//	public void setSalary(double salary) {
//		Salary = salary;
//	}
//	public char getGrade() {
//		return grade;
//	}
//	public void setGrade(char grade) {
//		this.grade = grade;
//	}
//	public String getJoiningDate() {
//		return joiningDate;
//	}
//	public void setJoiningDate(String joiningDate) {
//		this.joiningDate = joiningDate;
//	}
//	
//	
//	
//	
//	
//	
//	
//}
