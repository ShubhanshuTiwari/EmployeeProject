package Employee;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Scanner;
public class PermanentEmployee {

	static int  empId=1000;
	EmployeeBean employeebean[]=new EmployeeBean[100];
	static int  count=0;
	public String addEmployee() {
		Scanner sc=new Scanner(System.in);
		empId++;
		System.out.println("enter employee first name");
		String fName=sc.nextLine();
		System.out.println("enter employee last name");
		String lName=sc.nextLine();
		System.out.println("enter salary ");
		double salary=sc.nextDouble();
		System.out.println("enter employee grade");
		char grade=sc.next().charAt(0);
		sc.nextLine();
		System.out.println("Enter employee joinning date(dd:mm:yyyy)");
		String joiningDate=sc.nextLine();
//		try {
//		   DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
//	        joiningDate = formatter.format(joiningDate);
//		}
//		catch(Exception e) {
//			System.out.println("you have entered date in wrong format");
//			return"Make the date in correct format";
//		}
		
		
		employeebean[count]=new EmployeeBean(empId,fName,lName,salary,grade,joiningDate);
		count++;
		return "Details Added Successfully";
	}
	public String showEmployee() {
		String show="";
		if(count>0) {
		for(int i=0;i<count;i++) {
			show+="\nTotal no of employees are::"+count+"\nEmployee Id is::"+employeebean[i].getEmpId()+"\nEmployee First Name::"+ employeebean[i].getFname()+ " \n Employee Last name: "+ employeebean[i].getLname()+"\nEmployee salary::"+employeebean[i].getSalary()+"\nEmployee grade"+employeebean[i].getGrade()+"\nEmployee joining date:"+employeebean[i].getJoiningDate()+"\n";
			
		}
		return show;
		}
		else {
			return  "No employee is here";
		}
		
		
	}
	
	
	
	
	
}
