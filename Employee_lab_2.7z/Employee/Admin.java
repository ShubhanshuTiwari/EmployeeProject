package Employee;

import java.util.Scanner;

public class Admin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		PermanentEmployee  permanentemployee=new PermanentEmployee();
		while(true) {
			System.out.println("Enter Your choice");
			System.out.println("1:::Add Employee");
			System.out.println("2::Count Employee");
			System.out.println("3::Exit");
			int choice=sc.nextInt();
			switch(choice) {
			case 1:System.out.println(" if You want to add Permanent Employee press 1 or contract Employee 2");
					int empChoice=sc.nextInt();
					switch(empChoice) {
					case 1:
						break;
					case 2: 
						break;
					default:System.out.println("Enter wrong choice");
							break;
					
					}
				
				String s=permanentemployee.addEmployee();
					System.out.println(s);
				 break;
			case 2:String m=permanentemployee.showEmployee();
				System.out.println(m);
				break;
			case 3:System.exit(0);
				break;
			default:System.out.println();
			}
			
		}
	}

}
