package com.capgemini.employeebean;

public class EmployeeNotFoundException extends Exception  {
	
	
	
}
