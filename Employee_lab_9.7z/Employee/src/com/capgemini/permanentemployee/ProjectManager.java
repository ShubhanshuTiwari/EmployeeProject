package com.capgemini.permanentemployee;

import com.capgemini.container.Date;
import com.capgemini.container.Mediclaim;

public class ProjectManager extends PermanentEmployee {
	


	private double salary;
	public ProjectManager(String fname, String lname, double salary, char grade, Date joiningDate) {
		super(fname, lname, salary, grade, joiningDate);
		// TODO Auto-generated constructor stub
		
		
	}
	
	

	



	public ProjectManager() {
		// TODO Auto-generated constructor stub
	
	}







	Mediclaim mediclaim=new Mediclaim(getSalary() );
	@Override
	public String toString() {
		return "ProjectManager  getId()=" + getId() + ", getFname()=" + getFname() + ", getLname()=" + getLname()
				+ ", getSalary()=" + getSalary() + ", getGrade()=" + getGrade() + ", getJoiningDate"
				+ getJoiningDate()+"mediclaim coverage" +mediclaim.getSalary()*2 + "]";
	}
	
public boolean search(int id) {
		
		if(getId()==id)
			return true;
		
		return false;
	}

	

		
	
		
}
