package com.capgemini.permanentemployee;

import com.capgemini.container.Date;
import com.capgemini.container.Mediclaim;

public class TechnicalAssociate extends PermanentEmployee {

	
	public TechnicalAssociate(String fname, String lname, double salary, char grade, Date joiningDate) {
		super(fname, lname, salary, grade, joiningDate);
		// TODO Auto-generated constructor stub
	}
	public TechnicalAssociate(){
		
	}
	Mediclaim mediclaim=new Mediclaim(getSalary() );
	@Override
	public String toString() {
		return "TechnicalAssociate of permanent employee "+ ", getId()=" + getId() + ", getFname()="
				+ getFname() + ", getLname()=" + getLname() + ", getSalary()=" + getSalary() + ", getGrade()="
				+ getGrade() + ", getJoiningDate()=" + getJoiningDate()+"getMediclaim()"+mediclaim.getSalary();
	}
public boolean search(int id) {
		
		if(getId()==id)
			return true;
		
		return false;
	}
	
}
