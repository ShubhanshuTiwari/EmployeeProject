package com.capgemini.contractemployee;

import com.capgemini.container.Contractor;
import com.capgemini.container.Date;
import com.capgemini.container.Mediclaim;
import com.capgemini.employeebean.Employee;

public class TechnicalAssociate extends ContractEmployee {

	public TechnicalAssociate(String fname, String lname, double salary, char grade, Date doj, int hours,
			Contractor contractor) {
		super(fname, lname, salary, grade, doj, hours, contractor);
		// TODO Auto-generated constructor stub
	}
	public TechnicalAssociate() {}
	@Override
	public String toString() {
		return "TechnicalAssociate of contract employee [  "+"getId()=" + getId()
				+ ", getFname()=" + getFname() + ", getLname()=" + getLname() + ", getSalary()=" + getSalary()
				+ ", getGrade()=" + getGrade() + ", getJoiningDate()=" + getJoiningDate() +
				"hours=" + hours
				+ ", getContractor()=" + getContractor() 
				;
	}
public boolean search(int id) {
		
		if(getId()==id)
			return true;
		
		return false;
	}
	
	


	
	
	
	
	
	
}
