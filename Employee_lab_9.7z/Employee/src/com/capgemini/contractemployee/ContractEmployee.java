package com.capgemini.contractemployee;



import com.capgemini.container.Contractor;
import com.capgemini.container.Date;
import com.capgemini.employeebean.Employee;

public class ContractEmployee extends Employee {


	int hours;
	Contractor contractor;
	public static int count=0;
	public ContractEmployee(String fname, String lname, double salary,char grade, Date doj,int hours,Contractor contractor) {
		
		super(fname, lname, salary,grade, doj);// super yaha jarruri h
		
		this.hours=hours;
		this.contractor=contractor;
		count++;
	}
	public ContractEmployee() {
		
	}
	
	public int getHours() {
		return hours;
	}
	public void setHours(int hours) {
		this.hours = hours;
	}
	public Contractor getContractor() {
		return contractor;
	}
	public void setContractor(Contractor contractor) {
		this.contractor = contractor;
	}
	
	
	
	
	
}
