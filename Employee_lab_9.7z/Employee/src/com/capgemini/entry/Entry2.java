package com.capgemini.entry;

import com.capgemini.container.Contractor;
import com.capgemini.container.Date;
import com.capgemini.employeebean.Employee;
import com.capgemini.employeebean.EmployeeNotFoundException;
import com.capgemini.permanentemployee.ProjectManager;
import com.capgemini.permanentemployee.TechnicalAssociate;

public class Entry2 {

	public static void main(String args[]) throws EmployeeNotFoundException {
	
		Employee emp[]=new Employee[10];
		Date date=new Date(01,16,2019);
		for(int i=0;i<3;i++) {
		emp[i]=new Employee("dinesh","kartik",2000,'A',date);
		}
		boolean flag=false;
		for(int i=0;i<3;i++) {
			flag=emp[i].search(2);
			
		
		
		if(flag==true) {
			System.out.println(emp[i].toString());
			break;
		}
		}
		if(flag==false)
			throw new EmployeeNotFoundException();
		
		
		
		
		
	Employee[]permanentEmp_projectMngr=new ProjectManager[3];
	Employee  []permanentEmp_technicalMngr=new com.capgemini.permanentemployee.TechnicalAssociate[3];
	Employee []contractEmp_technicalMngr=new com.capgemini.contractemployee.TechnicalAssociate[3];
		for(int i=0;i<3;i++) {
		permanentEmp_projectMngr[i]=new ProjectManager("mahendra","dhoni",2000,'A',date);
		}
		for(int i=0;i<3;i++) {
			permanentEmp_technicalMngr[i]=new com.capgemini.permanentemployee.TechnicalAssociate("mahendra","dhoni",2000,'A',date);
			}
		
		int rate=20;
		int hour=5;
	Contractor contractor=new Contractor("shastri",rate);
	Contractor contractor2=new Contractor("garry",20);
		int ratebasedsalary=rate*hour;
		for(int i=0;i<3;i++) {
		contractEmp_technicalMngr[i] =new com.capgemini.contractemployee.TechnicalAssociate("Rishabh","pant",ratebasedsalary,'A',date,hour,contractor);
		}
				
		
		for(int i=0;i<permanentEmp_projectMngr.length;i++) {
	System.out.println(permanentEmp_projectMngr[i].toString());
		}
		for(int i=0;i<permanentEmp_technicalMngr.length;i++) {
			System.out.println(permanentEmp_technicalMngr[i].toString());
				}
		for(int i=0;i<contractEmp_technicalMngr.length;i++) {
			System.out.println(contractEmp_technicalMngr[i].toString());
				}

		
		boolean flag2=false;
		for(int i=0;i<3;i++) {
			flag=permanentEmp_projectMngr[i].search(5);
			
		
		
		if(flag==true) {
			System.out.println(permanentEmp_projectMngr[i].toString());
			break;
		}
		}
		if(flag==false)
			throw new EmployeeNotFoundException();
		
		boolean flag3=false;
		for(int i=0;i<3;i++) {
			flag=permanentEmp_technicalMngr[i].search(7);
			
		
		
		if(flag==true) {
			System.out.println(emp[i].toString());
			break;
		}
		}
		if(flag==false)
			throw new EmployeeNotFoundException();
		boolean flag4=false;
		for(int i=0;i<3;i++) {
			flag=contractEmp_technicalMngr[i].search(10);
			
		
		
		if(flag==true) {
			System.out.println(emp[i].toString());
			break;
		}
		}
		if(flag==false)
			throw new EmployeeNotFoundException();
		
		
		
		
		
		
		
		
		
		
		
		
		}
	
	
}
