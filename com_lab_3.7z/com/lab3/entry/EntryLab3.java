package com.lab3.entry;
import java.util.Scanner;
import com.capgemini.beans.*;
import com.capgemini.beans.Date;
public class EntryLab3 {
	
	
	static int permanentCount=0;
	static int contractCount=0;
	public static void main(String[] args) {
		Date date=new Date(01,16,2019);
		Employee john=new Employee("john","son",2000,date);	
		Employee sachin=new Employee("Sachin","Tendulkar",20000,date);	
		Employee virat=new Employee("Virat","kohli",2000,date);	

		Permanent_Employee dhoni=new Permanent_Employee("mahendra","dhoni",2000,date);
		Permanent_Employee dinesh=new Permanent_Employee("dinesh","kartik",2000,date);
		Permanent_Employee pant=new Permanent_Employee("Rishabh","pant",2000,date);
		
		int rate=20;
		int hour=5;
		Contractor contractor=new Contractor("shastri",rate);
		Contractor contractor2=new Contractor("garry",20);
		int ratebasedsalary=rate*hour;
		Contract_Based_Employee shami=new Contract_Based_Employee("mohamad","shami",ratebasedsalary,date,hour,contractor);
		Contract_Based_Employee bhuvi=new Contract_Based_Employee("bhuvaneshwar","kumar",ratebasedsalary,date,hour,contractor2);
		
		
		System.out.println(john.toString());
		System.out.println(dhoni.toString());
		System.out.println(shami.toString());
		System.out.println(shami.getContractor());
		System.out.println(Employee.count);
		System.out.println(Permanent_Employee.count);
		System.out.println(Contract_Based_Employee.count);
//		System.out.println();
//		System.out.println();
//		System.out.println();
//		System.out.println();
		System.out.println(john.getId());
		System.out.println(dhoni.getFname());
		System.out.println(shami.getDoj());
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		Scanner sc=new Scanner(System.in);
//		while(true) {
//			System.out.println("Enter a choice");
//			System.out.println("1 for add employee");
//			Date d1 = new Date(31,01,2018); 
//			Employee permanent_employee=new Permanent_Employee("ram","shyam",20000,d1);
//			Contractor contractor=new Contractor("Raman",12000);
//			Employee contract_based_employee=new Contract_Based_Employee("rajat","chingi",2000,d1,contractor);	
//			System.out.println("2 for show employee");
//			System.out.println("3 for exit");
//			int choice=sc.nextInt();
//			switch(choice) {
//			case 1:  permanentCount++;
//					contractCount++;
//				    break;
//			case 2:System.out.println("Enter 1 to display contracter based details");
//				System.out.println("Enter 2 to display permanent based details");
//					int choicee=sc.nextInt();
//					switch(choicee) {
//					case 1:System.out.println(permanent_employee.toString());
//						break;
//					case 2:System.out.println(contract_based_employee.toString());
//						break;
//					default:
//						break;
//					}
//				break;
//			case 3: System.exit(0);
//					break;
//			default:System.out.println("wrong choice");
//			         break;
//			
//			}
			
		}
	
	
	
	
}
