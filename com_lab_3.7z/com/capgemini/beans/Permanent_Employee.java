package com.capgemini.beans;

public class Permanent_Employee extends Employee {
	public static int count=0;
	public Permanent_Employee(String fname, String lname, double salary, Date doj) {
		super(fname, lname, salary, doj);// super yaha jarruri h
	count++;
	}

	

}
