package com.capgemini.beans;

public class Contract_Based_Employee extends Employee {
	
	
	int hours;
	Contractor contractor;
	public static int count=0;
	public Contract_Based_Employee(String fname, String lname, double salary, Date doj,int hours,Contractor contractor) {
		
		super(fname, lname, salary, doj);// super yaha jarruri h
		
		this.hours=hours;
		this.contractor=contractor;
		count++;
	}
	
	public double getSalary() {
		return 10;
	}

	public int getHours() {
		return hours;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

	public Contractor getContractor() {
		return contractor;
	}

	public void setContractor(Contractor contractor) {
		this.contractor = contractor;
	}

	public static int getCount() {
		return count;
	}

	public static void setCount(int count) {
		Contract_Based_Employee.count = count;
	}

	
//	public String toString() {
//		return "Contract_Based_Employee [hours=" + hours + ", contractor=" + contractor + "]";
//	}
	
	
	
	

}
