package com.capgemini.beans;

public class Date {
		int day;
		int month;
		int year;
		public Date(int day, int month, int year) {
			
			this.day = day;
			this.month = month;
			this.year = year;
		}	
		
 public String display() {
	return Integer.toString(this.day)+"/"+Integer.toString(this.month)+"/"+Integer.toString(this.year);
	}

@Override
public String toString() {
	return "day=" + day + ", month=" + month + ", year=" + year ;
}
 
}
