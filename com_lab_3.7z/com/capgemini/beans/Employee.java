package com.capgemini.beans;

public class Employee {
	public static int count=0;
	double id=(int)1000*Math.random();
	String fname;
	String lname;
	double salary;
	Date doj;
	public Employee(String fname, String lname, double salary, Date doj) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.salary = salary;
		this.doj = doj;
		count++;
	}
	
	public static int getCount() {
		return count;
	}

	public static void setCount(int count) {
		Employee.count = count;
	}

	public double getId() {
		return id;
	}

	public void setId(double id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	@Override
	public String toString() {
		return "Employee -->id=" + id + ", fname=" + fname + ", lname=" + lname + ", salary=" + salary + ", doj=" + doj;
	}
	
	
	
	
	
}
