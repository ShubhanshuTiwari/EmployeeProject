package com.capgemini.container;

public class Contractor {
	String name;
	double rate;
	public Contractor(String name, double rate) {
		super();
		this.name = name;
		this.rate = rate;
	}
	@Override
	public String toString() {
		return "Contractor [name=" + name + ", rate=" + rate + "]";
	}
	
}
