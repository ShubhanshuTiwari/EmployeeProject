package com.capgemini.container;

public class Mediclaim {
	 int coverAmount;
	 double salary;
	
	 
	 
	public Mediclaim( double salary) {
		this.salary = salary;
	}



	public double getSalary() {
		return salary;
	}



	

	

	
	
}
