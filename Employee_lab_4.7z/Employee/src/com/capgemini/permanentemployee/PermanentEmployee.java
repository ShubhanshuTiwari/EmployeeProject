package com.capgemini.permanentemployee;

import com.capgemini.container.Date;
import com.capgemini.employeebean.Employee;

public class PermanentEmployee extends Employee {

	public PermanentEmployee(String fname, String lname, double salary, char grade, Date joiningDate) {
		super(fname, lname, salary, grade, joiningDate);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "PermanentEmployee [toString()=" + super.toString() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + "]";
	}
		
}
