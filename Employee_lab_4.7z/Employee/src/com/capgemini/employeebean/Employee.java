package com.capgemini.employeebean;

import com.capgemini.container.Date;

public class Employee {

	private double id=(int)1000*Math.random();
	private String fname;
	private String lname;
	private double Salary;
	private char grade;
	private Date joiningDate;
	
	public Employee( String fname, String lname, double salary, char grade, Date joiningDate) {
		super();
		
		this.fname = fname;
		this.lname = lname;
		Salary = salary;
		this.grade = grade;
		this.joiningDate = joiningDate;
	}
	public String toString() {
		return "Employee -->id=" + id + ", fname=" + fname + ", lname=" + lname + ", salary=" + Salary + ", doj=" + joiningDate;
	}
	public double getId() {
		return id;
	}
	public void setId(double id) {
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	public char getGrade() {
		return grade;
	}
	public void setGrade(char grade) {
		this.grade = grade;
	}
	public Date getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}
	
	
	
	
	
	
	
	
	
	
	
}
