package com.capgemini.entry;


import com.capgemini.container.Contractor;
import com.capgemini.container.Date;
import com.capgemini.container.Mediclaim;
import com.capgemini.permanentemployee.TechnicalAssociate;
import com.capgemini.employeebean.Employee;
import com.capgemini.permanentemployee.ProjectManager;
//import com.capgemini.contractemployee.TechnicalAssociate;

public class Entry {
	public static void main(String args[]) {
	Date date=new Date(01,16,2019);
	Employee dhoni=new ProjectManager("mahendra","dhoni",2000,'A',date);
	Employee dinesh=new TechnicalAssociate("dinesh","kartik",2000,'A',date);
	int rate=20;
	int hour=5;
	Contractor contractor=new Contractor("shastri",rate);
	Contractor contractor2=new Contractor("garry",20);
	int ratebasedsalary=rate*hour;
	Employee rishabh =new com.capgemini.contractemployee.TechnicalAssociate("Rishabh","pant",ratebasedsalary,'A',date,hour,contractor);
	System.out.println(dhoni.toString());
	System.out.println(dinesh.toString());
	System.out.println(rishabh.toString());
	
	}
}
